# Disney Solitaire Bot — projekt Android

To jest początkowy szkielet aplikacji Android dla telefonu Samsung.

## Co zawiera wersja 0.1.0
- ekran aplikacji,
- usługę Android Accessibility do diagnostycznego odczytu tekstu interfejsu,
- GitHub Actions do zbudowania testowego pliku APK.

## Ważne ograniczenie
Ta wersja **nie rozpoznaje kart i nie gra automatycznie**. Usługa odczytuje wyłącznie tekst udostępniany przez interfejs Androida. Karty mogą być rysowane jako grafika, więc rozpoznawanie kart i logika ruchów wymagają osobnego etapu implementacji i testów na prawdziwym ekranie gry.

## Budowanie APK przez GitHub
1. Wgraj zawartość archiwum do głównego katalogu repozytorium `tomosk666-cpu/Disney-Solitarie-Bot`.
2. Zatwierdź zmiany na gałęzi `main`.
3. Otwórz zakładkę **Actions**.
4. Uruchom workflow **Build Android APK**.
5. Po zakończeniu pobierz artefakt `Disney-Solitarie-Bot-debug`.

## Wymagania
JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3 i Android SDK platform 35.
