package pl.tomosk666.disneysolitariebot

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Diagnostic only: reads accessible text and does not interact with the game. */
class GameAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        try {
            val summary = StringBuilder()
            collectVisibleText(root, summary, 0)
            Log.d("SolitaireBot", "Visible UI text: $summary")
        } finally {
            root.recycle()
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo, out: StringBuilder, depth: Int) {
        if (depth > 12 || out.length > 3000) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let {
            out.append(it).append(" | ")
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try { collectVisibleText(child, out, depth + 1) }
            finally { child.recycle() }
        }
    }

    override fun onInterrupt() {
        Log.d("SolitaireBot", "Accessibility service interrupted")
    }
}
