package pl.tomosk666.disneysolitariebot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Disney Solitaire Bot\\nWersja testowa 0.1.0"
            textSize = 23f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "To jest początkowa wersja testowa.\\n\\n1. Otwórz ustawienia dostępności.\\n2. Znajdź Disney Solitaire Bot na liście usług.\\n3. Włącz usługę, jeśli chcesz przetestować odczyt tekstu ekranu.\\n\\nTa wersja nie rozpoznaje jeszcze kart i nie wykonuje ruchów automatycznie."
            textSize = 16f
        }
        val settings = Button(this).apply {
            text = "Otwórz ustawienia dostępności"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        setContentView(layout)
    }
}
